


document.addEventListener("DOMContentLoaded", function(){
            
  window.addEventListener('scroll', function() {
     
      if (window.scrollY > 170) {
          document.querySelector('.nav-bar').classList.add('nav-fix');
          document.querySelector('.dropdown').style.top= "70px"
          console.log(document.querySelector('.nav-bar'))

      } else {
           document.querySelector('.nav-bar').classList.remove('nav-fix');
          document.querySelector('.dropdown').style.top= "167px"

           // remove padding top from body
      } 
  });
}); 

activeLink()

