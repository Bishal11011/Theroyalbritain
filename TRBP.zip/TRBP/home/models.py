from django.db import models

# Create your models here.
 

class Festivals(models.Model):
	name = models.CharField(max_length=200)
	image = models.ImageField(upload_to='images/festival',null=True, blank=True ,)
	description=models.TextField(null=True,blank=True)


	def __str__(self):
		return self.name





